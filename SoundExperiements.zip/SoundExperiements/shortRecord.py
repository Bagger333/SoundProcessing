from SoundExperiements.Filters import *

p = pyaudio.PyAudio()

stream = p.open(format=FORMAT,
                channels=CHANNELS,
                rate=RATE,
                input=True,
                output=True,
                frames_per_buffer=chunk)

print("* recording")
while stream.is_active():
    data = stream.read(chunk)
    # %dh = Big-endian unassigned two-byte short
    data = np.array(wave.struct.unpack("%dh" % (len(data) / swidth), data))

    # Compute the one-dimensional discrete Fourier Transform for real input.
    data = np.fft.rfft(data) # real numbers to imaginary numbers
    # Pitch Shift Function
    data = pitchShift(data) # imaginary numbers coming out

    # inverse transform to get back to temporal data
    data = np.fft.irfft(data) # back to real float numbers
    dataout = np.array(data, dtype='int16') # convert to int numbers

    # tremolo Effect
    # dataout = addTremelo(dataout, modulationAmp, modulationDigFreq)

    # All Pass Filter
    # modData = allpassFiltering(dataout, fractionalDelay)
    # Vibrato
    #dataout = addVibrato(dataout, maxDelay, digModFreq)
    # dataout = allpassFiltering(dataout,fractionalDelay)
    dataDone = np.array(dataout, dtype='int16')
    chunkout = wave.struct.pack("%dh" % (len(dataDone)), *list(dataDone))  # convert back to 16-bit data
    stream.write(chunkout)

print("* done")

stream.stop_stream()
stream.close()
p.terminate()
