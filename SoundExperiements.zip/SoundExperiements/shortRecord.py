from SoundExperiements.Filters import *
p = pyaudio.PyAudio()

stream = p.open(format=FORMAT,
                channels=CHANNELS,
                rate=RATE,
                input=True,
                output=True,
                frames_per_buffer=chunk)


print("* recording")
while stream.is_active():
    data = stream.read(chunk)
    # %dh = Big-endian unassigned two-byte short
    data = np.array(wave.struct.unpack("%dh" % (len(data) / swidth), data))

    # do real fast Fourier transform
    data = np.fft.rfft(data)

    # Pitch Shift Function
    data = pitchShift(data)

    # inverse transform to get back to temporal data
    data = np.fft.irfft(data)
    dataout = np.array(data, dtype='int16')

    # tremolo Effect
    #dataout = addTremelo(dataout, modulationAmp,modulationDigFreq)

    #All Pass Filter
    samplingIndices = np.arange(chunk)
    signal = np.cos(digFreq * samplingIndices)
    #modData = allpassFiltering(dataout, fractionalDelay)
    # Vibrato
    #dataout = addVibrato(modData, maxDelay,digModFreq)
    # Echo
    dataout = combfiltering(dataout, filterCoef, delay)
    dataout = allpassFiltering(dataout,fractionalDelay)
    dataDone = np.array(dataout, dtype='int16')
    chunkout = wave.struct.pack("%dh" % (len(dataDone)), *list(dataDone))  # convert back to 16-bit data
    stream.write(chunkout)

print("* done")

stream.stop_stream()
stream.close()
p.terminate()