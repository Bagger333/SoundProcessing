import sys, time
import numpy as np
import wave
import pyaudio

# For the stream
chunk = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
RECORD_SECONDS = 5
swidth = 2

# for Pitch Shift
pitch = 5  # this is how the pitch should change, positive integers increase the frequency, negative integers decrease it.

# For Tremolo
modulationDigFreq = 2 * np.pi * 20 / RATE  # rad/sample
modulationAmp = 0.9  # changes this to increase the effect strenght

# For Vibrato
maxDelay = 0.005*RATE  # samples
digModFreq = 2 * np.pi * 5 / RATE  # rad/sample


def pitchShift(dataIn):
    # Create a new zero array of the same lenght as the in data
    data2 = [0] * len(dataIn)
    if pitch >= 0:
        # data2[X:Y] = Take all points from the Xth position, to the Y position
        # meaning if you have 500 samples and X = 0 and Y = 3, its going to print only the first three variables of the Array
        # Take from the end and reduce sample size
        data2[pitch:len(dataIn)] = dataIn[0:(len(dataIn) - pitch)]
        # Take from the beginning and reduce samples size
        data2[0:pitch] = dataIn[(len(dataIn) - pitch):len(dataIn)]
    else:
        data2[0:(len(dataIn) + pitch)] = dataIn[-pitch:len(dataIn)]
        data2[(len(dataIn) + pitch):len(dataIn)] = dataIn[0:-pitch]
    # we then create a new np array with the newly calculated data
    data3 = np.array(data2)
    # we then return it
    return data3


def addTremelo(inputSignal, modulationAmp, modulationDigFreq):
    # create an int with the size our return array needs to be
    nData = np.size(inputSignal)
    # create an array containing each value up to nData
    samplingIndices = np.arange(nData)
    # do the Tremelo math, meaning take 1 - the modulation amp * cos(modulation digital Frequency * the sampling Indices array values)
    modulatingSignal = 1 - modulationAmp * np.cos(modulationDigFreq * samplingIndices)
    # add the modulationSignal values to the original signal and return it
    return inputSignal * modulatingSignal


def addVibrato(inputSignal, modDepth, digModFreq, offset=1):
    nData = np.size(inputSignal)
    # create two empty arrays to contain the modified data
    outputSignal = np.zeros(nData)
    tmpSignal = np.zeros(nData)
    for n in np.arange(nData):
        # calculate delay
        delay = offset + (modDepth / 2) * (1 - np.cos(digModFreq * n))
        # calculate filter output
        if n < delay:
            outputSignal[n] = 0
        else:
            # take delay and round it to the nearest whole int
            intDelay = np.int(np.floor(delay))
            tmpSignal[n] = inputSignal[n - intDelay]
            # calculate fractional delay for allpass filter
            fractionalDelay = delay - intDelay
            # use fractionalDelay to calculate apParameter to apply an allpass filter to the results
            apParameter = (1 - fractionalDelay) / (1 + fractionalDelay)
            # do the vibrato math
            outputSignal[n] = apParameter * tmpSignal[n] + tmpSignal[n - 1] - apParameter * outputSignal[n - 1]
    return outputSignal
