import sys, time
import numpy as np
import wave
import pyaudio

#For the stream
chunk = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
RECORD_SECONDS = 5
swidth = 2

# for Pitch Shift
pitch = 5  # this is how the pitch should change, positive integers increase the frequency, negative integers decrease it.

# For Tremolo
modulationDigFreq = 2*np.pi*20/RATE # rad/sample
modulationAmp = 0.9

# For Vibrato
maxDelay = 0.01*RATE # samples
digModFreq = 2*np.pi*5/RATE # rad/sample

# For CombFilter / Echo
filterCoef = 0.5
delay = np.int(np.round(0.15*RATE)) # samples



def pitchShift(dataIn):
    # This does the shifting
    data2 = [0] * len(dataIn)

    if pitch >= 0:
        data2[pitch:len(dataIn)] = dataIn[0:(len(dataIn) - pitch)]
        data2[0:pitch] = dataIn[(len(dataIn) - pitch):len(dataIn)]
        print(len(data2))
    else:
        data2[0:(len(dataIn) + pitch)] = dataIn[-pitch:len(dataIn)]
        data2[(len(dataIn) + pitch):len(dataIn)] = dataIn[0:-pitch]

    data3 = np.array(data2)
    return data3



def addTremelo(inputSignal, modulationAmp, modulationDigFreq):
    nData = np.size(inputSignal)
    samplingIndices = np.arange(nData)
    modulatingSignal = 1-modulationAmp*np.cos(modulationDigFreq*samplingIndices)
    return inputSignal*modulatingSignal


def addVibrato(inputSignal, modDepth, digModFreq, offset=1):
    nData = np.size(inputSignal)
    outputSignal = np.zeros(nData)
    tmpSignal = np.zeros(nData)
    for n in np.arange(nData):
        # calculate delay
        delay = offset + (modDepth/2)*(1-np.cos(digModFreq*n))
        # calculate filter output
        if n < delay:
            outputSignal[n] = 0
        else:
            intDelay = np.int(np.floor(delay))
            tmpSignal[n] = inputSignal[n-intDelay]
            fractionalDelay = delay-intDelay
            apParameter = (1-fractionalDelay)/(1+fractionalDelay)
            outputSignal[n] = apParameter*tmpSignal[n]+tmpSignal[n-1]-apParameter*outputSignal[n-1]
    return outputSignal


def combfiltering(inputSignal, filterCoef, delay, feedBackIsUsed=True):
    nData = np.size(inputSignal)
    outputSignal = np.zeros(nData)
    for n in np.arange(nData):
        if n < delay:
            outputSignal[n] = inputSignal[n]
        else:
            if feedBackIsUsed:
                outputSignal[n] = inputSignal[n]+filterCoef*outputSignal[n-delay]
            else:
                outputSignal[n] = inputSignal[n]+filterCoef*inputSignal[n-delay]
    return outputSignal