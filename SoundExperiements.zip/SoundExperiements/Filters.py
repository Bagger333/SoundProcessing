from SoundExperiements.effects import *

# For allpass filter
digFreq = 0.3  # rad/sample
fractionalDelay = 0.3


# allpass filter
def allpassFiltering(inputSignal, fractionalDelay):
    apParameter = (1 - fractionalDelay) / (1 + fractionalDelay)
    nData = np.size(inputSignal)
    outputSignal = np.zeros(nData)
    for n in np.arange(nData):
        if n == 0:
            outputSignal[n] = apParameter * inputSignal[n]
        else:
            outputSignal[n] = apParameter * inputSignal[n] + inputSignal[n - 1] - apParameter * outputSignal[n - 1]
    return outputSignal


def lowpassFiltering(inputSignal, limiter):
    nData = np.size(inputSignal)
    outputSignal = np.zeros(nData)
    for n in np.arange(nData):
        if n > limiter:
            outputSignal[n:] = limiter
        else:
            outputSignal[n:] = inputSignal[n:]
    return outputSignal


def highpassFiltering(inputSignal, limiter):
    nData = np.size(inputSignal)
    outputSignal = np.zeros(nData)
    for n in np.arange(nData):
        if n < limiter:
            outputSignal[n:] = limiter
        else:
            outputSignal[n:] = inputSignal[n:]
    return outputSignal
